import { Component, NgModule } from '@angular/core';
import { MarketplaceItemType } from '../marketplace/types/marketplace.type';
import { Subscription } from 'rxjs';
import { CartService } from '../services/cart.service';
import { CommonModule } from '@angular/common';
import { ProductService } from '../services/product.service';


@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  isSideBarVisable:boolean = false;

  cartItems:  {item:MarketplaceItemType,quantity:number}[] = [];
  cartItemsSub!: Subscription;

  constructor(public cartService: CartService,public productService: ProductService) {}

  ngOnInit(): void {
    this.cartItemsSub = this.cartService
      .getCartItems()
      .subscribe((cartItems) => {
        this.cartItems = cartItems;
      });
  }

  toggleSidebar() {
    this.isSideBarVisable = !this.isSideBarVisable;
  }

  oneLess =(cart : {item:MarketplaceItemType,quantity : number}) =>{
    if (cart.quantity - 1 < 1) {
      this.productService.productRemovedFromCart(cart.item,1);
      this.cartService.removeItem(cart.item);
    }else{
      this.productService.editProduct(cart.item,1);
      this.cartService.editItem(cart.item,-1);
    }
  }

  oneMore =(cart : {item:MarketplaceItemType,quantity : number}) =>{
    if (cart.item.quantity - 1 < 0) return;
    this.productService.editProduct(cart.item,-1);
    this.cartService.editItem(cart.item,1);
  }

  ngOnDestroy(): void {
    this.cartItemsSub.unsubscribe();
  }
}
