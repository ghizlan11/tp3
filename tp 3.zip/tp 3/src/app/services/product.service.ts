import { Injectable } from '@angular/core';
import { MarketplaceItemType } from '../marketplace/types/marketplace.type';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private _products: MarketplaceItemType[] = [
    {
      id: 1,
      title: 'ADIDAR MAX',
      category: 'ADULT',
      image: 'https://via.placeholder.com/500',
      description:
        'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.',
      price: 65.0,
      quantity: 10,
      isSelected: false,
    },
    {
      id: 2,
      title: 'LEBRON MAX AIR',
      category: 'KIDS',
      image: 'https://via.placeholder.com/500',
      description:
        'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.',
      price: 65.0,
      quantity: 5,
      isSelected: false,
    },
    {
      id: 3,
      title: 'PUMA XS',
      category: 'ADULT',
      image: 'https://via.placeholder.com/500',
      description:
        'Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.',
      price: 4.99,
      quantity: 3,
      isSelected: false,
    },
  ];
  constructor() {}

  getProdutcs = (): Observable<Array<MarketplaceItemType>> => {
    return of(this._products);
  };

  productAddedToCart = (item: MarketplaceItemType, quantity: number = 1) => {
    if (item.quantity - quantity < 0) {
      return false;
    }
    item.isSelected = true;
    item.quantity -= quantity;
    return true;
  };

  editProduct = (item: MarketplaceItemType, quantity: number) => {
    let product  = this._products.find(pr => item.id === pr.id);
    if (product) {
      product.quantity += quantity;
    }
  };

  productRemovedFromCart = (item: MarketplaceItemType, quantity: number) => {
    item.isSelected = false;
    item.quantity += quantity;
  };
}
