import { Component } from '@angular/core';
import { MarketplaceItemType } from '../types/marketplace.type';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-marketplace-item-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './marketplace-item-list.component.html',
  styleUrl: './marketplace-item-list.component.scss',
})
export class MarketplaceItemListComponent {
  productsSub!: Subscription;
  marketplaceItems: MarketplaceItemType[] = [];

  constructor(
    public productService: ProductService,
    public cartService: CartService
  ) {}

  ngOnInit(): void {
    this.productsSub = this.productService
      .getProdutcs()
      .subscribe((products) => {
        this.marketplaceItems = products;
      });
  }

  addToCart = (item: MarketplaceItemType) => {
    if (this.productService.productAddedToCart(item)) {
      this.cartService.addItem(item, 1);
    }
  };

  removeFromCart = (item: MarketplaceItemType) => {
    const cartitem = this.cartService.getCartItem(item.id);
    if(cartitem){
      this.productService.productRemovedFromCart(item,cartitem.quantity);
      this.cartService.removeItem(item);
    }
  };

  ngOnDestroy(): void {
    this.productsSub.unsubscribe();
  }
}
